pyBarcode's Documentation
=========================

.. image:: /images/pybarcode.png

Contents
--------

.. toctree::
   :maxdepth: 2

   barcode
   commandline
   codes
   writers/index
   license

Indices and tables
==================

* :ref:`search`

Latest version
==============

You can always download the latest release
`here <https://bitbucket.org/whitie/python-barcode/downloads/>`_.

Related Links
=============

:Project page: https://bitbucket.org/whitie/python-barcode/

:Issues: https://bitbucket.org/whitie/python-barcode/issues/

:Wiki: https://bitbucket.org/whitie/python-barcode/wiki/Home

